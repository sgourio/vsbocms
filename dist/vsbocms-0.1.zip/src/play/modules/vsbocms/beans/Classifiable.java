package play.modules.vsbocms.beans;

public interface Classifiable extends Comparable<Classifiable>{
	public Long getId();
	public String getName();
}
