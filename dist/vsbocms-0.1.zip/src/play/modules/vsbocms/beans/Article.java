package play.modules.vsbocms.beans;

public interface Article extends Classifiable{
}
