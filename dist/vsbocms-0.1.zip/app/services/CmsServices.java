//package services;
//
//import java.io.Serializable;
//import java.lang.reflect.Method;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.TreeSet;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;
//
//import models.vsbocms.FolderAssociation;
//import models.vsbocms.SimpleFolder;
//import play.Logger;
//import play.cache.Cache;
//import play.modules.vsbocms.VsboCmsPlugin;
//import play.modules.vsbocms.beans.Article;
//import play.modules.vsbocms.beans.Classifiable;
//import play.modules.vsbocms.beans.Folder;
//
///**
// * Content management system services
// * @author Sylvain Gourio
// *
// */
//public class CmsServices implements Serializable{
//
//	private SimpleFolder rootFolder = null;
//	
//	private Map<Classifiable, Set<Classifiable>> contentTree = Collections.synchronizedMap(new HashMap<Classifiable, Set<Classifiable>>());
//	private Map<String, Classifiable> contentIdMap = Collections.synchronizedMap(new HashMap<String, Classifiable>());
//	
//	/**
//	 * Prepare the root folder wich is not in the database
//	 */
//	private CmsServices() {
//		rootFolder = new SimpleFolder();
//		rootFolder.id = 0L;
//		rootFolder.folderName = "vsbocms.rootFolder";
//	}
//	
//	/**
//	 * A cmsServices instance is in cache for 1 day
//	 * @return
//	 */
//	public static CmsServices getInstance(){
//		CmsServices instance = (CmsServices) Cache.get("CmsServices_instance");
//		if( instance == null ){
//			Lock lock = new ReentrantLock();
//			try{
//				lock.lock();
//				instance = (CmsServices) Cache.get("CmsServices_instance");
//				if( instance == null ){
//					instance = new CmsServices();
//					Cache.safeSet("CmsServices_instance", instance, "1d");
//				}
//			}finally{
//				lock.unlock();
//			}
//			
//		}
//		
//		return instance;
//	}
//	
//	/**
//	 * Get the folder tree (with articles too)
//	 * @return
//	 */
//	public Map<Classifiable, Set<Classifiable>> getFolderTree(){
//		if( contentTree.isEmpty() ){
//			Lock lock = new ReentrantLock();
//			try{
//				lock.lock();
//				buildFolderTree(contentTree, rootFolder, new ArrayList<Long>());
//			}finally{
//				lock.unlock();
//			}
//		}
//		return contentTree;
//	}
//	
//	/**
//	 * build the folder tree
//	 * @param folderTree
//	 * @param currentRoot
//	 * @param folderAlreadyTraited (avoid infinite loop)
//	 */
//	private void buildFolderTree(final Map<Classifiable, Set<Classifiable>> folderTree, Classifiable currentRoot, List<Long> folderAlreadyTraited){
//		
//		if( folderAlreadyTraited.contains(currentRoot.getId()) ){
//			return;
//		}
//		folderAlreadyTraited.add(currentRoot.getId());
//		
//		List<FolderAssociation> subFolderList = FolderAssociation.findByFolderId(currentRoot.getId());
//		if( subFolderList != null && !subFolderList.isEmpty() ){
//			for( FolderAssociation association : subFolderList ){
//				 try {
//					Class<?> clazz = Class.forName(association.classOfElement);
//					if( Folder.class.isAssignableFrom(clazz) ){
//						Method method = clazz.getMethod("findById", Object.class);
//						Folder folder = (Folder) method.invoke(null, association.elementId );
//						Set<Classifiable> currentList = folderTree.get(currentRoot);
//						if( currentList == null ){
//							currentList = new TreeSet<Classifiable>();
//							folderTree.put(currentRoot, currentList);
//						}
//						currentList.add(folder);
//						buildFolderTree(folderTree, folder, folderAlreadyTraited);
//					}else if( Article.class.isAssignableFrom(clazz)  ){
//						Method method = clazz.getMethod("findById", Object.class);
//						Article article= (Article) method.invoke(null, association.elementId );
//						Set<Classifiable> currentList = folderTree.get(currentRoot);
//						if( currentList == null ){
//							currentList = new TreeSet<Classifiable>();
//							folderTree.put(currentRoot, currentList);
//						}
//						currentList.add(article);
//					}
//				} catch (Exception e) {
//					Logger.error(e, "Error" );
//				}
//			}
//		}else{
//			folderTree.put(currentRoot, new HashSet<Classifiable>());
//		}
//	}
//	
//	/**
//	 * Get a map of the content organized by id.
//	 * The id is the result of concatenation : name of the object class +"_"+ id of the object
//	 * @return
//	 */
//	public Map<String, Classifiable> getContentIdMap() {
//		if( this.contentIdMap.isEmpty() ){
//			Lock lock = new ReentrantLock();
//			try{
//				lock.lock();
//				// init the folderIdMap ( id , folder )
//				for ( Classifiable f : this.getFolderTree().keySet()){
//					this.contentIdMap.put(f.getClass().getName() +"_"+ f.getId(), f);
//					for( Classifiable cl : this.getFolderTree().get(f)){
//						this.contentIdMap.put(cl.getClass().getName() +"_"+ cl.getId(), cl);
//					}
//				}
//			}finally{
//				lock.unlock();
//			}
//		}
//		return contentIdMap;
//	}
//
//	/**
//	 * get the root folder of the tree
//	 * @return
//	 */
//	public Folder getRootFolder() {
//		return rootFolder;
//	}
//	
//	/**
//	 * Get articles directly inside a folder
//	 * @param folder
//	 * @return
//	 */
//	public List<Article> getArticleFromFolder(Folder folder){
//		List<Article> result = new ArrayList<Article>();
//		Set<Classifiable> classifiableSet = getFolderTree().get(folder.getClass().getName()+"_"+folder.getId());
//		for(Classifiable cl : classifiableSet ){
//			if( cl instanceof Article ){
//				result.add((Article) cl);
//			}
//		}
//		return result;
//	}
//	
//	/**
//	 * Get folders directly inside a folder
//	 * @param folder
//	 * @return
//	 */
//	public List<Folder> getFolderFromFolder(Folder folder){
//		List<Folder> result = new ArrayList<Folder>();
//		Set<Classifiable> classifiableSet = getFolderTree().get(folder.getClass().getName()+"_"+folder.getId());
//		for(Classifiable cl : classifiableSet ){
//			if( cl instanceof Folder ){
//				result.add((Folder) cl);
//			}
//		}
//		return result;
//	}
//	
//	/**
//	 * Put a classifiable object in the folder tree
//	 * @param content
//	 * @param parentFolder
//	 */
//	public void classify(Classifiable content , Classifiable parentFolder ){
//		
//		Set<Classifiable> classifiableList = contentTree.get(parentFolder);
//		if( classifiableList == null ){
//			classifiableList = new TreeSet<Classifiable>();
//			contentTree.put(parentFolder, classifiableList);
//		}
//		
//		boolean contain = false;
//		for( Classifiable in : classifiableList){
//			if( in.getId() == content.getId() && in.getClass().equals(content.getClass()) ){
//				classifiableList.remove(in);
//				contain = true;
//				break;
//			}
//		}
//		
//		if( !contain ){
//
//			FolderAssociation folderAssociation = new FolderAssociation();
//			folderAssociation.classOfElement = content.getClass().getName();
//			folderAssociation.elementId = content.getId();
//			folderAssociation.folderId = parentFolder.getId();
//			folderAssociation.save();
//			
//			classifiableList.add(content);
//		}else{
//			classifiableList.add(content);
//			if( content instanceof Folder ){
//				buildFolderTree(contentTree, content, new ArrayList<Long>());
//			}
//		}
//		contentIdMap.put(content.getClass().getName() +"_"+ content.getId(), content);
//	}
//	
//	
//	/**
//	 * List of different folder classes existing in the project
//	 * @return
//	 */
//	public List<Class<?>> getFolderClassList(){
//		return VsboCmsPlugin.getFoldersClassList();
//	}
//	
//	/**
//	 * List of different articles classes existing in the project
//	 * @return
//	 */
//	public List<Class<?>> getArticleClassList(){
//		return VsboCmsPlugin.getArticlesClassList();
//	}
//	
//	/**
//	 * Delete the classifiable object.
//	 * If it's a folder, the object inside are also deleted
//	 * @param classifiable
//	 */
//	public void delete(Classifiable classifiable){
//		recursiveDelete(classifiable);
//		contentTree = Collections.synchronizedMap(new HashMap<Classifiable, Set<Classifiable>>()); // force rebuilt tree
//	}
//	
//	private void recursiveDelete(Classifiable classifiable){
//		if( classifiable instanceof Folder){
//			for( Classifiable cl :  getFolderTree().get(classifiable)){
//				recursiveDelete(cl);
//			}	
//		}
//		try{
//			List<FolderAssociation> folderAssociationList = FolderAssociation.findByElementId(classifiable.getId(), classifiable.getClass().getName());
//			for( FolderAssociation fa : folderAssociationList ){
//				fa.delete();
//			}
//			Method method = classifiable.getClass().getMethod("findById", Object.class);
//			Classifiable cl = (Classifiable) method.invoke(null, classifiable.getId() );
//			cl.delete();
//		} catch (Exception e) {
//			Logger.error(e,"");
//		}
//	}
//}
