package controllers.vsbocms;

import java.util.Map;

import play.modules.vsbocms.beans.Folder;
import play.mvc.Controller;
import services.CmsServices;

public class SimpleFolder extends Controller{

	public static void edit(Long parentFolderId, Long id){
		if( parentFolderId != null ){
			Folder currentFolder = (Folder) CmsServices.getInstance().getContentIdMap().get(parentFolderId);
			if( currentFolder != null ){
				renderArgs.put("currentFolder", currentFolder);
			}
		}
		
		if( id == null){
			render();
		}else{
			models.vsbocms.SimpleFolder simpleFolder = models.vsbocms.SimpleFolder.findById(id);
			render(simpleFolder);
		}
	}
}
