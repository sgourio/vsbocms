package play.modules.vsbocms.beans;

public interface Folder extends Classifiable{
}
